<?php echo form_open('cargo/add',array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="nombreCargo" class="col-md-4 control-label">NombreCargo</label>
		<div class="col-md-8">
			<input type="text" name="nombreCargo" value="<?php echo $this->input->post('nombreCargo'); ?>" class="form-control" id="nombreCargo" />
		</div>
	</div>
	<div class="form-group">
		<label for="sueldoCargo" class="col-md-4 control-label">SueldoCargo</label>
		<div class="col-md-8">
			<input type="text" name="sueldoCargo" value="<?php echo $this->input->post('sueldoCargo'); ?>" class="form-control" id="sueldoCargo" />
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>

<?php echo form_close(); ?>