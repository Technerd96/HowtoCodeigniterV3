<div class="pull-right">
	<a href="<?php echo site_url('empleado/add'); ?>" class="btn btn-success">Add</a> 
</div>

<table class="table table-striped table-bordered">
    <tr>
		<th>IdEmpleado</th>
		
		<th>Nombre Empleado</th>
		<th>Sueldo</th>
		<th>Cargo</th>
		<th>Actions</th>
    </tr>
	<?php foreach($empleado as $e){ ?>
    <tr>
		<td><?php echo $e['idEmpleado']; ?></td>
		
		<td><?php echo $e['nombreEmpleado']; ?></td>
		<td><?php echo $e['sueldoCargo']; ?></td>
		<td><?php echo $e['nombreCargo']; ?></td>
		<td>
            <a href="<?php echo site_url('empleado/edit/'.$e['idEmpleado']); ?>" class="btn btn-info btn-xs">Edit</a> 
            <a href="<?php echo site_url('empleado/remove/'.$e['idEmpleado']); ?>" class="btn btn-danger btn-xs">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>
