<?php echo form_open('empleado/add',array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="idCargo" class="col-md-4 control-label">Cargo</label>
		<div class="col-md-8">
			<select name="idCargo" class="form-control">
				<option value="">select cargo</option>
				<?php 
				foreach($all_cargo as $cargo)
				{
					$selected = ($cargo['idCargo'] == $this->input->post('idCargo')) ? ' selected="selected"' : "";

					echo '<option value="'.$cargo['idCargo'].'" '.$selected.'>'.$cargo['nombreCargo'].'</option>';
				} 
				?>
			</select>
		</div>
	</div>
	<div class="form-group">
		<label for="nombreEmpleado" class="col-md-4 control-label">NombreEmpleado</label>
		<div class="col-md-8">
			<input type="text" name="nombreEmpleado" value="<?php echo $this->input->post('nombreEmpleado'); ?>" class="form-control" id="nombreEmpleado" />
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>

<?php echo form_close(); ?>