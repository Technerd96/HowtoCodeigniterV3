<div class="text-center">
	<h2>Este es un tutorial de como funciona Codeigniter 3</h2>
</div>

<td>
            <a href="<?php echo site_url('empleado/'); ?>" class="btn btn-success">EMPLEADO</a> 
			<a href="<?php echo site_url('cargo/'); ?>" class="btn btn-primary">CARGO</a>
		
</td>